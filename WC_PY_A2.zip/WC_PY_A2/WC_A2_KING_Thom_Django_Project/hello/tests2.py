from django.test import TestCase
from .models import HelloDetails, HelloContact

class HelloDetailsModelTest(TestCase):
    def test_hello_details_creation(self):
        # Create a HelloDetails instance
        hello_details = HelloDetails(name="John Doe", email="johndoe@example.com")
        hello_details.save()

        # Retrieve the HelloDetails instance from the DB
        saved_hello_details = HelloDetails.objects.get(name="John Doe")

        # Ensure retrieved instance match the original
        self.assertEqual(saved_hello_details.name, "John Doe")
        self.assertEqual(saved_hello_details.email, "johndoe@example.com")
        print("Success!")

class HelloContactModelTest(TestCase):
    def test_hello_contact_creation(self):
        # Create one HelloContact instance
        hello_contact = HelloContact(name="Contact Name", email="contact@example.com")
        hello_contact.save()

        # Retrieve HelloContact instance from the database
        saved_hello_contact = HelloContact.objects.get(name="Contact Name")

        # Ensure retrieved instance match the original
        self.assertEqual(saved_hello_contact.name, "Contact Name")
        self.assertEqual(saved_hello_contact.email, "contact@example.com")
        print("Success also!🙂")