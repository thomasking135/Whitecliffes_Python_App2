
from django.shortcuts import redirect, render

from django.shortcuts import render #render pages added
import re
from django.utils.timezone import datetime
from django.http import HttpResponse

from hello.forms import DetailsForm

#Add the signups
from .models import HelloDetails

#Add the tutors
from .models import HelloContact



from django.shortcuts import render

def home(request):
    return render(request, "home.html")

def about(request):
    return render(request, "about.html")

def contact(request):
    return render(request, "contact.html")


def submit_details(request):
    if request.method == 'POST':
        form = DetailsForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, "contact.html")  # Redirect to a success page
    else:
        form = DetailsForm()
    return render(request, 'contact.html', {'form': form})

def contact_list(request):
    # Your view logic here
    return render(request, 'contact.html')


#To show database content :)
def contact(request):
    data = HelloDetails.objects.all()
    return render(request, 'contact.html', {'data': data})


#Add the tutors function
def about(request):
    contacts = HelloContact.objects.all()
    return render(request, 'about.html', {'contacts': contacts})
# add the tutors function



