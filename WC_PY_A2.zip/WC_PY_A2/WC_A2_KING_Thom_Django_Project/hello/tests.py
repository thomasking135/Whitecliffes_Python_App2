from django.test import TestCase
#from .models import HelloDetails
from .forms import DetailsForm

class DetailsFormTest(TestCase):
    def test_form_valid(self):
        form_data = {
            'name': 'John Doe',
            'email': 'john@example.com',
            # Add other form fields as needed
        }
        form = DetailsForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_form_invalid(self):
        # Create an empty form (no data) and verify that it's invalid
        form = DetailsForm(data={})
        self.assertFalse(form.is_valid())

    def test_form_fields(self):
        form = DetailsForm()
        # Verify that the form contains the expected fields
        self.assertIn('name', form.fields)
        self.assertIn('email', form.fields)
        # Add assertions for other form fields as needed

    def test_hello(self):
        print("That's all folks")

