from django import forms
from .models import HelloDetails

class DetailsForm(forms.ModelForm):
    class Meta:
        model = HelloDetails
        fields = ['name', 'email']