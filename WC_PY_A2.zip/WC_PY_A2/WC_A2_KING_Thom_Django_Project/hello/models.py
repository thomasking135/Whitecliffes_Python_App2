from django.db import models


class HelloDetails(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()

    class Meta:
        db_table = 'hello_names' #hello_hellodetails;

class HelloContact(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=25)

    class Meta:
        db_table = 'hello_contact'

    def __str__(self):
        return self.name
        



